import pandas as pd
from langchain_core.documents import Document
from typing import List

def create_chunks(csvFile, sortingColumn) -> List[Document]:
    if csvFile is None:
        return None
    
    lineLimit = 5
    rows = []
    for idx, row in pd.read_csv(csvFile).iterrows():
        rows.append((row.to_dict()))
    if(len(rows)>0):
        rows = sorted(rows, key=lambda row: row[sortingColumn])
        rows = list(str(row) for row in rows)
    
    chunks = []
    for i in range(0, len(rows), lineLimit):
        if not (i+lineLimit>len(rows)):
            chunks.append(Document(page_content="\n".join(row for row in rows[i:i+lineLimit])))
    print(f"No. of chunks created : {len(chunks)}")
    return chunks