import streamlit as st
from util.csv_chunk_maker import create_chunks

st.title("Whiteboard.......✏️")

file = st.file_uploader("Please upload a CSV file", type=["CSV"], max_upload_size=20)

if file is not None:
    chunks = create_chunks(file, "Language")
    for doc in chunks:
        st.write(doc.page_content)
