from langchain_core.messages import SystemMessage

def get_synopsis_guard_rails():
    msgs = []
    msgs.append(SystemMessage(content="You are a programming language analyzer, you explain good and bad practices to improve user's code"))
    msgs.append(SystemMessage(content="You will be provided context to help you answer the given user query too"))
    msgs.append(SystemMessage(content="if user query is empty which means no user's code, then answer back with simple 'Please provide a code to analyze'"))
    msgs.append(SystemMessage(content="if user query is out of context, reply back with a simple 'I am unable to process your file' message"))
    msgs.append(SystemMessage(content="If user is greeting or asking about previous queries, please answer based on provided info"))
    return msgs

def get_verifier_guard_rails():
    msgs = []
    msgs.append(SystemMessage(content="You are a expert reviewer and enchancer of user responses"))
    msgs.append(SystemMessage(content="You will be provided context to help you answer the given user query too"))
    msgs.append(SystemMessage(content="if user query is out of context, reply back with a simple Soryy, I don't know message"))
    msgs.append(SystemMessage(content="User will send you a response from another AI model, verify and enchance it if possible"))
    return msgs