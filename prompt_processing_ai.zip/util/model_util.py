import os
import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_ollama import OllamaEmbeddings, ChatOllama

# -----------------------------------
# Tiktoken fix (VERY IMPORTANT)
# -----------------------------------
tiktoken_cache_dir = "./token"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir
api_key = "sk-X8HaEtflRvOrnRy6ZZ2fsw"


def get_chat_model_online():

    client = httpx.Client(verify=False)

    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        # model="azure_ai/genailab-maas-DeepSeek-V3-0324",
        model = "azure/genailab-maas-gpt-4o",
        # model = "azure/genailab-maas-gpt-35-turbo", 
        api_key=api_key,
        http_client=client,
        temperature=0
    )
    return llm

def get_embedding_model_online():
    
    client = httpx.Client(verify=False)

    return OpenAIEmbeddings(
        base_url="https://genailab.tcs.in",
        model="azure/genailab-maas-text-embedding-3-large",
        api_key=api_key,
        http_client=client
    )

def get_chat_model_offline():
    return ChatOllama(model="deepseek-r1",temperature=0.2)

def get_embedding_model_offline():
    return OllamaEmbeddings(model="gte-large")


def get_chat_verifier_online():

    client = httpx.Client(verify=False)

    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model="azure_ai/genailab-maas-DeepSeek-V3-0324",
        # model = "azure/genailab-maas-gpt-4o",
        # model = "azure/genailab-maas-gpt-35-turbo", 
        api_key=api_key,
        http_client=client,
        temperature=0
    )
    return llm