from util.model_util import get_chat_model_offline, get_chat_model_online, get_embedding_model_offline, get_embedding_model_online
from util.vector_store_util import create_vector_store, load_local_vector
from util.pdf_chunk_maker import create_chunks
from util.guard_rail_util import get_synopsis_guard_rails, get_verifier_guard_rails
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_community.vectorstores import *

def get_context(vectorstore: VectorStore, query: str):
    context = ""
    chunks = vectorstore.similarity_search(query, k=3)
    for doc in chunks:
        context += " . " + doc.page_content
    return context

def prepare_synopsis_prompt(query, vectorstore):
    messages = get_synopsis_guard_rails()
    context = get_context(vectorstore, query)
    messages.append(SystemMessage(content=". Here is the context <code>" + context + "</code>"))
    messages.append(HumanMessage(content=query))
    return messages

def prepare_verifier_prompt(firstResponse):
    messages = get_verifier_guard_rails()
    messages.append(HumanMessage(content=". Here is the response from another model <response>" + firstResponse + "</response> check if it okay and enchance it"))
    return messages