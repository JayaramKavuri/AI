import pdfplumber
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

def create_chunks(pdfFile):
    if pdfFile is None:
        return None
    
    pdf = pdfplumber.open(pdfFile)
    extractedText = ""
    for pages in pdf.pages:
        extractedText +=  "\n" + pages.extract_text()
    documents = [Document(page_content=extractedText)]
    textSplitter = RecursiveCharacterTextSplitter(
        chunk_size = 500,
        chunk_overlap = 50,
        separators=["\n\n", "\n", "##", "#", ".", " "]
    )

    chunks = textSplitter.split_documents(documents)
    print(f"No. of chunks created : {len(chunks)}")
    return chunks