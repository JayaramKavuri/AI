
from langchain_community.vectorstores import FAISS

def create_vector_store(embeddings, chunks, indexName):

    print("Processing chunks into vectors...")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    print("Vectorstore generated !")
    vectorstore.save_local("faiss_"+indexName)
    return "faiss_"+indexName

def load_local_vector(indexName, embeddings):
    return FAISS.load_local(indexName, embeddings, allow_dangerous_deserialization=True)