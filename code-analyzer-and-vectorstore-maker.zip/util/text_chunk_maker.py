from langchain_text_splitters import RecursiveCharacterTextSplitter
from streamlit.runtime.uploaded_file_manager import UploadedFile as stFile
from langchain_core.documents import Document

def create_chunks(txtFile: stFile):
    if txtFile is None:
        return None
    
    txtData = txtFile.read().decode("utf-8")
    txtDoc = [Document(page_content=txtData)]
    splitter = RecursiveCharacterTextSplitter(
        chunk_size = 500,
        chunk_overlap = 50,
        separators=["##","#","\n","."," "]
    )

    chunks = splitter.split_documents(txtDoc)
    print(f"No. of chunks created : {len(chunks)}")
    return chunks
