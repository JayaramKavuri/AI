import streamlit as st
from util.model_util import get_chat_model_offline, get_chat_model_online, get_embedding_model_offline, get_embedding_model_online, get_chat_verifier_online
from util.vector_store_util import create_vector_store, load_local_vector
from util import pdf_chunk_maker, csv_chunk_maker, text_chunk_maker
from util.prompt_util import prepare_synopsis_prompt, prepare_verifier_prompt
from streamlit.runtime.uploaded_file_manager import UploadedFile as stFile
from fastapi import UploadFile
import pdfplumber
import io

def get_chunks(file: stFile):
    if(file.name.endswith(".pdf")):
        return pdf_chunk_maker.create_chunks(file)
    elif(file.name.endswith(".csv")):
        return csv_chunk_maker.create_chunks(file, "Language")
    elif(file.name.endswith(".txt")):
        return text_chunk_maker.create_chunks(file)

async def process_query(file: UploadFile):
    if file.filename.lower().endswith(".pdf"):
        content = await file.read()
        text = ""
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
        query = text
    else:
        query = await file.read()
        query = query.decode("utf-8", errors="ignore")

    embedding = get_embedding_model_online()
    # vectorBaseIndex = create_vector_store(embedding, get_chunks(file), file.name)
    vectorBaseIndex = "faiss_code_practices_dataset_large"
    vectorstore = load_local_vector(vectorBaseIndex, embedding)
    prompt = prepare_synopsis_prompt(query, vectorstore)
    llm = get_chat_model_online()
    verifier_llm = get_chat_verifier_online()
    
    print("Processing query...")
    response = llm.invoke(prompt)
    print("Query processed!")

    # Uncomment the below lines to activate multi modal verification

    # verifier_prompt = prepare_verifier_prompt(response.content)
    # print("Going for secondary processing...")
    # finalResponse = verifier_llm.invoke(verifier_prompt)
    # print("Your answer is ready")
    # return (finalResponse.content)
    return (response.content)