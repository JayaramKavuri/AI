import streamlit as st
from util.model_util import get_chat_model_offline, get_chat_model_online, get_embedding_model_offline, get_embedding_model_online
from util.vector_store_util import create_vector_store, load_local_vector
from util import pdf_chunk_maker, csv_chunk_maker, text_chunk_maker
from util.prompt_util import prepare_synopsis_prompt
from streamlit.runtime.uploaded_file_manager import UploadedFile as stFile

st.title("Knowledge Base Factory 💡")

st.write(" -- Please upload your file to turn it into a reusable vectorstore")

file = st.file_uploader("Upload your file", max_upload_size=20, type=["PDF", "CSV", "TXT"])

def get_chunks(file: stFile):
    if(file.name.endswith(".pdf")):
        return pdf_chunk_maker.create_chunks(file)
    elif(file.name.endswith(".csv")):
        return csv_chunk_maker.create_chunks(file, "Language")
    elif(file.name.endswith(".txt")):
        return text_chunk_maker.create_chunks(file)

if file is not None:

    query = "What do you?"
    embedding = get_embedding_model_online()
    vectorBaseIndex = create_vector_store(embedding, get_chunks(file), file.name)
    vectorstore = load_local_vector(vectorBaseIndex, embedding)
    prompt = prepare_synopsis_prompt(query, vectorstore)
    llm = get_chat_model_online()
    
    print("Processing query...")
    response = llm.invoke(prompt)
    print("Query processed!")
    st.write(response.content)
